package com.hollykunge.repository;

import com.hollykunge.model.VoteIpEmail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VoteIpEmailRepository extends JpaRepository<VoteIpEmail, Long> {
    List<VoteIpEmail> findByVoteId(@Param("voteId") Long voteId);
}
