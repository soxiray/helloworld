package com.hollykunge.service;

import com.hollykunge.model.VoteIpEmail;

import java.util.List;

public interface VoteIpEmailService {

    List<VoteIpEmail> findByVoteId(Long voteId);

}
