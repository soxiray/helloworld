package com.hollykunge.service.impl;

import com.hollykunge.model.VoteIpEmail;
import com.hollykunge.repository.VoteIpEmailRepository;
import com.hollykunge.service.VoteIpEmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VoteIpEmailServiceImpl implements VoteIpEmailService {
    @Autowired
    private VoteIpEmailRepository voteIpEmailRepository;

    @Override
    public List<VoteIpEmail> findByVoteId(Long voteId) {
        return voteIpEmailRepository.findByVoteId(voteId);
    }
}
