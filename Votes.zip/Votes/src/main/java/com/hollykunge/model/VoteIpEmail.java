package com.hollykunge.model;

import javax.persistence.*;

/**
 * @author dd
 */

@Entity
@Table(name = "vote_ip_email")
public class VoteIpEmail {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "vote_id")
    private Long voteId;

    @Column(name = "ip", unique = true)
    private String ip;

    @Column(name = "email", unique = true)
    private String email;

    public Long getVoteId() {
        return voteId;
    }

    public void setVoteId(Long voteId) {
        this.voteId = voteId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
