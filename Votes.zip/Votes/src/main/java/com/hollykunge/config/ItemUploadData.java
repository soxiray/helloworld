package com.hollykunge.config;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

@Data
public class ItemUploadData {
    @ExcelProperty(index = 0)
    private String attr0;
    @ExcelProperty(index = 1)
    private String attr1;
    @ExcelProperty(index = 2)
    private String attr2;
    @ExcelProperty(index = 3)
    private String attr3;
    @ExcelProperty(index = 4)
    private String attr4;
    @ExcelProperty(index = 5)
    private String attr5;
    @ExcelProperty(index = 6)
    private String attr6;
    @ExcelProperty(index = 7)
    private String attr7;
    @ExcelProperty(index = 8)
    private String attr8;
    @ExcelProperty(index = 9)
    private String attr9;
    @ExcelProperty(index = 10)
    private String attr10;
    @ExcelProperty(index = 11)
    private String attr11;
    @ExcelProperty(index = 12)
    private String attr12;

}