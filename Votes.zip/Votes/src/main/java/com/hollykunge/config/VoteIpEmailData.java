package com.hollykunge.config;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

@Data
public class VoteIpEmailData {

    @ExcelProperty("Office PC IP")
    private String ip;

    @ExcelProperty("Email address")
    private String email;
}
