$(function () {
    console.log(data)


})