var ot;
var oloaded;
// 弹窗显示
function showImportModel() {
    $('#importModel').modal('show');
    // 由于未刷新页面，需要对上一次上次内容初始化
    document.getElementById("time").innerHTML = '<div></div>';
    document.getElementById("percentage").innerHTML = '<div></div>';
    document.getElementById("progressBar").value = 0;
}

//定义按钮事件
function excelImport(voteId, fn) {
    ot = new Date().getTime(); //设置上传开始时间
    oloaded = 0; //设置上传开始时，以上传的文件大小为0
    var fileObj = document.getElementById("file").files[0]; // js 获取文件对象
    if (!fileObj) {
        alert('请选择一个Excel文件')
        return;
    }
    $('#copyCode').attr('disabled', 'disabled');
    $('#copyCode').find('.hide').removeClass('hide')
    var url = window.location.origin + "/vote/import"; // 接收上传文件的后台地址
    var form = new FormData(); // FormData 对象
    if (form) {
        form.append("file", fileObj); // 文件对象
    }
    var xhr = new XMLHttpRequest(); // XMLHttpRequest 对象
    xhr.open("post", url, true); //post方式，url为服务器请求地址，true 该参数规定请求是否异步处理。
    xhr.onload = fn; //请求完成
    xhr.onerror = uploadFailed; //请求失败
    xhr.upload.onprogress = progressFunction; //【上传进度调用方法实现】
    xhr.upload.onloadstart = function () { //上传开始执行方法
        ot = new Date().getTime(); //设置上传开始时间
        oloaded = 0; //设置上传开始时，以上传的文件大小为0
    };
    xhr.setRequestHeader("voteId", voteId);
    xhr.send(form); //开始上传，发送form数据
}